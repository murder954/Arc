package ru.sfedu.lab1;

import java.util.Collections;
import java.util.List;

public class Constans {
    public static final String PLANET = "Planet";
    public static final String PLANETS = "Planets";
    public static final String MONTH = "Month";
}
